package com.unlocked.unlocked;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnlockEdApplicationTests {

	@Test
	void contextLoads() {
	}

}

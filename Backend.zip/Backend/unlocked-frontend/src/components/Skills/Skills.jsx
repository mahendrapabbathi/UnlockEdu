// import React from 'react'
// import './Skills.css'
// import {useNavigate} from "react-router-dom"


// const Skills = () => {

//     const navigate = useNavigate();

//     const handleClick=()=>{
//         navigate("/dashboard")
//     }

//   return (
//     <div id='skills' className='skills'>
//             <ul>
//                 <div className="courses">
//                     <li onClick={handleClick}>C</li>
//                 </div>
//                 <div className="courses">
//                     <li onClick={handleClick}>Java</li>
//                 </div>
//                 <div className="courses">
//                     <li onClick={handleClick}>Python</li>
//                 </div>
//                 <div className="courses">
//                     <li onClick={handleClick}>Data Structures</li>
//                 </div>
//                 <div className="courses">
//                     <li onClick={handleClick}>Mysql</li>
//                 </div>
//                 <div className="courses">
//                     <li onClick={handleClick}>Javascript</li>
//                 </div>
//             </ul>
//     </div>
//   )
// }

// export default Skills

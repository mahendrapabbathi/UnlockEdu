import React from 'react'

const Toasting = () => {
  return (
    <div>
      
    </div>
  )
}

export default Toasting

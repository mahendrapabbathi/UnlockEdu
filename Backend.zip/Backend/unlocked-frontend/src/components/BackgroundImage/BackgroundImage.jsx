import React from 'react'
import './BackgroundImage.css'
// import { assets } from '../../assets/assets.js'

const BackgroundImage = () => {
  return (
    <div className='backContainer'>

      {/* <img src={assets.p1} alt="" /> */}
    </div>
  )
}

export default BackgroundImage

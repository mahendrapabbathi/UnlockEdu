import React from 'react'
import Dhero from '../../Course_components/DHero/Dhero'

const Dhome = () => {
  return (
    <div>
      <Dhero/>
    </div>
  )
}

export default Dhome

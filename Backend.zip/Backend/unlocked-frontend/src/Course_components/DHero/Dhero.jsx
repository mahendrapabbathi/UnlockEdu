import React from "react";
import "./Dhero.css";

const Dhero = () => {
  return (
    <div className="dhero">
      <h1>Learn How To Code</h1>
      <h2>with the UnlockEdu Developer site</h2>
    </div>
  );
};

export default Dhero;
